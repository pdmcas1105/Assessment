import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators'
import { HttpClient } from '@angular/common/http'
import { ProfileModel } from '../app.model';


@Injectable({
  providedIn: 'root'
})
export class BackendAPIService {
  profiles: ProfileModel [];
  constructor(private http : HttpClient) { }

  addProfile(data : any){
    return this.http.post<any>("https://jsonplaceholder.typicode.com/users",data)
    .pipe(map((res:any)=>{
      return res;
    }))
  }
  fetchProfile() {
    return this.http.get<any>("https://jsonplaceholder.typicode.com/users")
    .pipe(map((res:any)=>{
      return res;
    }))
  }
  updateProfile(data : any, id:number){
    return this.http.put<any>("https://jsonplaceholder.typicode.com/users"+id,data)
    .pipe(map((res:any)=>{
      return res;
    }))
  }
  deleteProfile(id : number){
    return this.http.delete<any>("https://jsonplaceholder.typicode.com/users/"+id)
    .pipe(map((res : any)=>{
      return res;
    }))
  }
}
