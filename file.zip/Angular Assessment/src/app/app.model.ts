export class ProfileModel{
    id : number = 0;
    name : string='';
    email : string='';
    phone : string='';
}