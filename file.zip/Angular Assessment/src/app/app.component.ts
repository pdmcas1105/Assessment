import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ProfileModel } from './app.model';
import { BackendAPIService } from './backend/backend-api.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  // profileForm : FormGroup;
  profileForm !: FormGroup;
  profileObj: ProfileModel = new ProfileModel();
  allProfiles : any;
  constructor(
    private formBuilder: FormBuilder,
    private api : BackendAPIService){ }

  ngOnInit(){
    // this.profileForm = new FormGroup({
    //   'name': new FormControl(null, Validators.required),
    //   'email': new FormControl(null, [Validators.required, Validators.email]),
    //   'phone': new FormControl(null, [Validators.required, Validators.pattern(/^-?(0|[0-9]\d*)?$/)])})

    this.profileForm = this.formBuilder.group({
      // id  : [''],
      name : [''],
      email : [''],
      phone : ['']
    })
    this.getallProfiles();
  }
  onSubmit(){
    console.log(this.profileForm);
  }
  postProfileData(){
    // this.profileObj.id = this.profileForm.value.id;
    this.profileObj.name = this.profileForm.value.name;
    this.profileObj.email = this.profileForm.value.email;
    this.profileObj.phone = this.profileForm.value.phone;

    this.api.addProfile(this.profileObj)
    .subscribe(res=>{
      console.log(res);
      alert("Profile Added")
      this.profileForm.reset();
      this.getallProfiles();
    },
    err=>{
      alert("Something Went Wrong")
  })
  }
  getallProfiles(){
    this.api.fetchProfile()
    .subscribe(res=>{
      this.allProfiles = res; 
    })
  }
  deleteProfileData(row:any){
    this.api.deleteProfile(row.id)
    .subscribe({
      next: res =>{
      alert("Successfully Deleted");
      this.getallProfiles();
      },
    })
  }
}
